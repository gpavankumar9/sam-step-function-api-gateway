import json

print('Loading UNSuccess function')


def lambda_handler(event, context):
    print("Not Successfully completed the request")