

import json

print('Loading Success function')


def lambda_handler(event, context):
    print("Successfully completed the request")
