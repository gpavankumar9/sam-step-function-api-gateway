
#API Gateway passes the input with some data in the event to LAMBDA

#  * eg:
#  * {
#  *   Price: '100.00',
#  *   Availability: 'Yes',
#  *   ownerPhone: '358440404040',
#  *    country: 'Finland',
#  *    city: 'Helsinki',
#  *    address: 'Katu 1234',
#  *    propertyName: 'La casita'
#  * }




import json

print('Loading Availability function')


def lambda_handler(event, context):
    if event['Availability'] > '':
        return True
    else:
        return False
